var fs=require('fs')
var express = require('express')
var app = express()
var multer=require('multer')
var bodyParser=require('body-parser')

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: false }));
var upload=multer({dest: 'uploads/'});

app.get('/index.html', (request, response) => {
	response.sendFile('index.html', {root:__dirname});
})

app.post('/get_resp', upload.single('file1'), (req, resp) => {
   	var temppath = req.file.path
  	var actualpath = 'uploads/' + req.file.originalname

	var src = fs.createReadStream(temppath)
	var dest = fs.createWriteStream(actualpath)
	src.pipe(dest)
	src.on('end', () => {
		 resp.write('uploaded to server') 
	})
	src.on('error', err => {
		 resp.write('error') 
	})

	fs.readFile(req.file.path, (err, data) => {
		if(err){
			resp.end("error reading file")
		}
		else{
			resp.end(data)
			console.log(data)
		}
	})
})
app.listen(3000, function(){
	console.log('listening on port 3000')
})
